"""
pytest tests — run with: pytest tests/ -v
Covers: register, login, token refresh, logout, role guards, change-password
"""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

# ── Fixtures ───────────────────────────────────────────────────────────────────
ADMIN = {
    "username": "admin_user", "email": "admin@test.com",
    "password": "Admin@1234", "full_name": "Admin User", "role": "admin",
}
EDITOR = {
    "username": "editor_user", "email": "editor@test.com",
    "password": "Editor@1234", "full_name": "Editor User", "role": "editor",
}
VIEWER = {
    "username": "viewer_user", "email": "viewer@test.com",
    "password": "Viewer@1234", "full_name": "Viewer User", "role": "viewer",
}


def register(data: dict) -> dict:
    r = client.post("/auth/register", json=data)
    assert r.status_code == 201, r.text
    return r.json()


def login(username: str, password: str) -> dict:
    r = client.post("/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return r.json()


def auth_header(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ── Register ──────────────────────────────────────────────────────────────────
class TestRegister:
    def test_register_success(self):
        r = client.post("/auth/register", json=ADMIN)
        assert r.status_code == 201
        body = r.json()
        assert body["username"] == "admin_user"
        assert "hashed_pw" not in body
        assert "password"  not in body

    def test_duplicate_username(self):
        r = client.post("/auth/register", json={**ADMIN, "email": "other@test.com"})
        assert r.status_code == 409

    def test_duplicate_email(self):
        r = client.post("/auth/register", json={**ADMIN, "username": "other_admin"})
        assert r.status_code == 409

    def test_weak_password(self):
        r = client.post("/auth/register", json={**VIEWER, "password": "weakpass"})
        assert r.status_code == 422

    def test_invalid_username_special_chars(self):
        r = client.post("/auth/register", json={**VIEWER, "username": "bad user!"})
        assert r.status_code == 422

    def test_register_editor(self):
        r = client.post("/auth/register", json=EDITOR)
        assert r.status_code == 201

    def test_register_viewer(self):
        r = client.post("/auth/register", json=VIEWER)
        assert r.status_code == 201


# ── Login ─────────────────────────────────────────────────────────────────────
class TestLogin:
    def test_login_success(self):
        tokens = login(ADMIN["username"], ADMIN["password"])
        assert "access_token"  in tokens
        assert "refresh_token" in tokens
        assert tokens["token_type"] == "bearer"
        assert tokens["expires_in"] == 1800

    def test_wrong_password(self):
        r = client.post("/auth/login", json={"username": ADMIN["username"], "password": "Wrong@999"})
        assert r.status_code == 401

    def test_wrong_username(self):
        r = client.post("/auth/login", json={"username": "nobody", "password": "Pass@123"})
        assert r.status_code == 401

    def test_error_message_same_for_wrong_user_and_wrong_pass(self):
        """No credential enumeration — both return same message."""
        r1 = client.post("/auth/login", json={"username": "nobody",         "password": "Pass@123"})
        r2 = client.post("/auth/login", json={"username": ADMIN["username"],"password": "WrongPass@1"})
        assert r1.json()["detail"] == r2.json()["detail"]


# ── Me & protected routes ──────────────────────────────────────────────────────
class TestProtectedRoutes:
    def test_me_authenticated(self):
        tokens = login(ADMIN["username"], ADMIN["password"])
        r = client.get("/auth/me", headers=auth_header(tokens["access_token"]))
        assert r.status_code == 200
        assert r.json()["username"] == "admin_user"

    def test_me_no_token(self):
        r = client.get("/auth/me")
        assert r.status_code == 401

    def test_me_bad_token(self):
        r = client.get("/auth/me", headers=auth_header("not.a.jwt.token"))
        assert r.status_code == 401

    def test_admin_list_users(self):
        tokens = login(ADMIN["username"], ADMIN["password"])
        r = client.get("/api/v1/users/", headers=auth_header(tokens["access_token"]))
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_viewer_cannot_list_users(self):
        tokens = login(VIEWER["username"], VIEWER["password"])
        r = client.get("/api/v1/users/", headers=auth_header(tokens["access_token"]))
        assert r.status_code == 403

    def test_editor_can_get_user_by_id(self):
        admin_tokens = login(ADMIN["username"], ADMIN["password"])
        users = client.get("/api/v1/users/", headers=auth_header(admin_tokens["access_token"])).json()
        uid = users[0]["id"]

        editor_tokens = login(EDITOR["username"], EDITOR["password"])
        r = client.get(f"/api/v1/users/{uid}", headers=auth_header(editor_tokens["access_token"]))
        assert r.status_code == 200

    def test_viewer_cannot_get_user_by_id(self):
        viewer_tokens = login(VIEWER["username"], VIEWER["password"])
        r = client.get("/api/v1/users/1", headers=auth_header(viewer_tokens["access_token"]))
        assert r.status_code == 403


# ── Token refresh ──────────────────────────────────────────────────────────────
class TestRefresh:
    def test_refresh_success(self):
        tokens = login(ADMIN["username"], ADMIN["password"])
        r = client.post("/auth/refresh", headers=auth_header(tokens["refresh_token"]))
        assert r.status_code == 200
        assert "access_token" in r.json()

    def test_refresh_token_is_rotated(self):
        """Old refresh token should be revoked after rotation."""
        tokens  = login(ADMIN["username"], ADMIN["password"])
        old_rt  = tokens["refresh_token"]
        # First refresh — works
        r1 = client.post("/auth/refresh", headers=auth_header(old_rt))
        assert r1.status_code == 200
        # Second refresh with same old token — should fail (rotated)
        r2 = client.post("/auth/refresh", headers=auth_header(old_rt))
        assert r2.status_code == 401

    def test_access_token_cannot_be_used_as_refresh(self):
        tokens = login(ADMIN["username"], ADMIN["password"])
        r = client.post("/auth/refresh", headers=auth_header(tokens["access_token"]))
        assert r.status_code == 401


# ── Logout ─────────────────────────────────────────────────────────────────────
class TestLogout:
    def test_logout_revokes_token(self):
        tokens = login(EDITOR["username"], EDITOR["password"])
        at = tokens["access_token"]
        # Before logout — works
        r1 = client.get("/auth/me", headers=auth_header(at))
        assert r1.status_code == 200
        # Logout
        r2 = client.post("/auth/logout", headers=auth_header(at))
        assert r2.status_code == 204
        # After logout — token blacklisted
        r3 = client.get("/auth/me", headers=auth_header(at))
        assert r3.status_code == 401

    def test_logout_without_token_is_ok(self):
        r = client.post("/auth/logout")
        assert r.status_code == 204


# ── Change password ─────────────────────────────────────────────────────────────
class TestChangePassword:
    def test_change_password_success(self):
        tokens = login(VIEWER["username"], VIEWER["password"])
        r = client.post(
            "/auth/change-password",
            json={"current_password": VIEWER["password"], "new_password": "NewViewer@999"},
            headers=auth_header(tokens["access_token"]),
        )
        assert r.status_code == 204
        # Can now login with new password
        new_tokens = login(VIEWER["username"], "NewViewer@999")
        assert "access_token" in new_tokens

    def test_change_password_wrong_current(self):
        tokens = login(EDITOR["username"], EDITOR["password"])
        r = client.post(
            "/auth/change-password",
            json={"current_password": "WrongPass@1", "new_password": "NewEditor@999"},
            headers=auth_header(tokens["access_token"]),
        )
        assert r.status_code == 400

    def test_change_password_same_as_current(self):
        tokens = login(EDITOR["username"], EDITOR["password"])
        r = client.post(
            "/auth/change-password",
            json={"current_password": EDITOR["password"], "new_password": EDITOR["password"]},
            headers=auth_header(tokens["access_token"]),
        )
        assert r.status_code == 400
